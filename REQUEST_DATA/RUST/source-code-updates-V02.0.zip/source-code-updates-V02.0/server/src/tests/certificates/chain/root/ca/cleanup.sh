#!/bin/sh

rm -rf certs crl newcerts private intermediate
rm index.*
rm serial*
rm chain_t0.pem
rm chain_t1.pem
